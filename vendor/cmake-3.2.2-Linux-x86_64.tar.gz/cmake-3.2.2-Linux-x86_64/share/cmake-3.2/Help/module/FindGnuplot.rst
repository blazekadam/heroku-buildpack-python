.. cmake-module:: ../../Modules/FindGnuplot.cmake

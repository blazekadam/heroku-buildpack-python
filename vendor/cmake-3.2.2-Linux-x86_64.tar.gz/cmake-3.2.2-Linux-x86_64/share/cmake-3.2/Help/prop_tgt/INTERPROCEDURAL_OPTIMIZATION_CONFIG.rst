INTERPROCEDURAL_OPTIMIZATION_<CONFIG>
-------------------------------------

Per-configuration interprocedural optimization for a target.

This is a per-configuration version of INTERPROCEDURAL_OPTIMIZATION.
If set, this property overrides the generic property for the named
configuration.

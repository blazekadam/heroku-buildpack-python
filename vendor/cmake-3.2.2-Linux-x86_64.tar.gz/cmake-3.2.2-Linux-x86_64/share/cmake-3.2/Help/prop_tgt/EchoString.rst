EchoString
----------

A message to be displayed when the target is built.

A message to display on some generators (such as makefiles) when the
target is built.

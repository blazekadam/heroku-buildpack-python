LIBRARY_OUTPUT_NAME
-------------------

.. |XXX| replace:: LIBRARY
.. |xxx| replace:: library
.. include:: XXX_OUTPUT_NAME.txt

RUNTIME_OUTPUT_NAME_<CONFIG>
----------------------------

Per-configuration output name for RUNTIME target files.

This is the configuration-specific version of RUNTIME_OUTPUT_NAME.

<CONFIG>_OUTPUT_NAME
--------------------

Old per-configuration target file base name.

This is a configuration-specific version of OUTPUT_NAME.  Use
OUTPUT_NAME_<CONFIG> instead.

LOCATION
--------

The full path to a source file.

A read only property on a SOURCE FILE that contains the full path to
the source file.
